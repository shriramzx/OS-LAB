# Operating Systems Lab

Programs for Experiments 3–15 of course 21CSC202J. Experiments 1 and 2 in the report follow the common sample format. Experiment 13 is **one experiment and one menu-driven Python program** that offers six disk scheduling choices.

Run commands from the `OS-LAB` folder.

## Experiments 3–8

```sh
clang Experiment-03/experiment3.c -Wall -Wextra -pthread -o Experiment-03/experiment3
clang Experiment-04/atm_semaphore.c -Wall -Wextra -pthread -o Experiment-04/atm_semaphore
clang Experiment-05/hospital.c -Wall -Wextra -pthread -o Experiment-05/hospital
clang Experiment-06/ev.c -Wall -Wextra -pthread -o Experiment-06/ev
clang Experiment-07/bankers.c -Wall -Wextra -o Experiment-07/bankers
clang Experiment-08/scheduling.c -Wall -Wextra -o Experiment-08/scheduling
```

Run each executable from its path, for example `./Experiment-03/experiment3`. Experiment 4 also contains `experiment4.c` for the second synchronization variant.

## Experiment 9 — Priority and Round Robin

```sh
clang Experiment-09/priority.c -Wall -Wextra -Wpedantic -o Experiment-09/priority
clang Experiment-09/round_robin.c -Wall -Wextra -Wpedantic -o Experiment-09/round_robin
```

## Experiment 10 — FIFO Page Replacement

```sh
clang Experiment-10/fifo.c -Wall -Wextra -Wpedantic -o Experiment-10/fifo
```

## Experiment 11 — LRU and LFU

```sh
python3 Experiment-11/lru.py
python3 Experiment-11/lfu.py
```

LFU resolves equal-frequency ties by least recent use.

## Experiment 12 — Best Fit and Worst Fit

```sh
python3 Experiment-12/best_fit.py
python3 Experiment-12/worst_fit.py
```

The sample uses variable-sized remaining free space; this assumption is printed by each program.

## Experiment 13 — Disk Scheduling Algorithm

One program contains FCFS, SSTF, SCAN, C-SCAN, LOOK, and C-LOOK:

```sh
python3 Experiment-13/disk_scheduling.py
```

Choose one algorithm, then enter the request queue, initial head position, and inclusive cylinder bounds. The sample queue `98 183 37 122 14 124 65 67`, head `53`, bounds `0` and `199`, and direction `right` gives total movement FCFS 640, SSTF 236, SCAN 331, C-SCAN 382, LOOK 299, and C-LOOK 322 cylinders.

## Experiment 14 — Sequential and Indexed File Allocation

```sh
clang Experiment-14/sequential_allocation.c -Wall -Wextra -Wpedantic -o Experiment-14/sequential_allocation
clang++ Experiment-14/indexed_allocation.cpp -Wall -Wextra -o Experiment-14/indexed_allocation
```

## Experiment 15 — Single-Level and Two-Level Directories

```sh
clang Experiment-15/single_level_directory.c -Wall -Wextra -Wpedantic -o Experiment-15/single_level_directory
clang Experiment-15/two_level_directory.c -Wall -Wextra -Wpedantic -o Experiment-15/two_level_directory
```

These directory programs model entries in memory; they do not change the Mac file system. Actual Mac screenshots appear in the report where supplied. Illustrative output text in the report is labeled and is not represented as a Mac screenshot.
